﻿using Microsoft.SqlServer.Server;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Permissions;
using System.Text;
using System.Threading.Tasks;

namespace herencia29102020
{
    abstract class hola
    {

        public abstract string saludo();

    }
    class accion:hola
    {
        protected string hola;
        public accion(string hola)
        {
            this.hola = hola;
        }
        public override string saludo()
        {
            return $"hola {hola} desde abstract";
        }
    }
    class profesor : trabajador
    {
        protected string materia;
        protected string area;
        public profesor(string area, string materia, string puesto, double salario, string Nombre, DateTime Edad)
            : base(puesto, salario, Nombre, Edad)
        {
            this.area = area;
            this.materia = materia;
        }
        public void print()
        {
            Console.WriteLine($"nombre:{nombre} \nEdad:{edad}\nPuesto:{puesto} Materia:{materia}\nArea:{area} salario:{salario}$\nID");
        }
        public bool busquedanombre(string entrada)
        {
            return nombre.ToLower().Trim().Contains(entrada);
        }//retorna el nombre
        public virtual void nuevonombre(string nuevonombre)
        {
            this.nombre = nuevonombre;
            Console.WriteLine("Nombre agregado");
        }//asigna un nuevo nombre a la clase
        public virtual void nuevopuesto(string nuevopuesto)
        {
            this.puesto = nuevopuesto;
            Console.WriteLine("puesto cambiado");
        }//cambio de puesto
        public virtual void nuevoarea(string nuevaarea)
        {
            this.area = nuevaarea;
        }//cambio de area
        public virtual void nuevamateria(string nuevamateria)
        {
            this.materia = nuevamateria;
        }//cambio de materia
        public void saludo()
        {
            accion hola = new accion(nombre);
            Console.WriteLine($"{ hola.saludo()}");
        }


    }
}
