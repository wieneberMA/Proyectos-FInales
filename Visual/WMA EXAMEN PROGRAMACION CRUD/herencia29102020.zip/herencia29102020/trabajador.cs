﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace herencia29102020
{

    class trabajador : persona
    {
        protected DateTime fechainicio = DateTime.Now;
        protected double salario;
        protected string puesto;
        protected string id;
        public trabajador(string puesto, double salario, string Nombre, DateTime Edad) : base(Nombre, Edad)
        {
            this.salario = salario;
            this.puesto = puesto;
            this.id = idjex();

        }//constructor
        public void imprimirid()
        {
            Console.WriteLine($"[{id}]");
        }//imprime credencial de trabajador
        private static string idjex()
        {
            Random rdm = new Random();
            string hexValue = string.Empty;
            int num;

            for (int i = 0; i < new Random().Next(1, 4); i++)
            {
                num = rdm.Next(0, int.MaxValue);
                hexValue += num.ToString("X8");
            }

            return hexValue;
        }//general el id de la credencial del trabajador
    }
}
