﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace herencia29102020
{
    class principal
    {
        static void Main(string[] args)
        {
            menu acceso = new menu();

            acceso.validacion();
        }
    }
}
