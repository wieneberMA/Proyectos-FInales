﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.Remoting.Proxies;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace herencia29102020
{
    public enum edicion { nombre =1, puesto, area, materia, salir }
    class menu
    {
        private List<estudiate> alumno = new List<estudiate>();
        private List<profesor> _profesor = new List<profesor>();
        private string _nombre;
        private DateTime _edad;
        private string _carrera;
        private int _semestre;
        private string[] administrador = {
            "wieneber"
        };
        private string[] pass = {
            "123"
        };
        public void validacion()
        {
            int intentos = 3;
            do
            {
                Console.WriteLine("////REGISTRO////\n");
                Console.WriteLine("USER");
                string user1 = Console.ReadLine();
                Console.WriteLine("password");
                string pass1 = Console.ReadLine();
                if (user1.ToLower().Trim() == administrador[0] && pass1.ToLower().Trim() == pass[0])
                {
                    Console.WriteLine($"hola [{user1}]");
                    registro();
                    Console.ReadLine();
                    principal();
                }
                else { intentos--; Console.WriteLine($"Error De Acceso Intentos[{intentos}]"); if (intentos == 0) { Environment.Exit(1); } }

            } while (true);
        }//acceso al sistema por administrador
        void principal()//menu principal 
        {
            Console.Clear();
            Console.WriteLine("1.-NUEVO REGISTRO\n2.-VER REGISTRO\n3.-BUSCAR REGISTRO\n4.-SALIR");
            int op = Convert.ToInt32(Console.ReadLine());
            switch (op)
            {
                case 1:
                    newregistro(true);
                    break;
                case 2:
                    newregistro(false);
                    break;
                case 3:
                    modificacion();
                    break;
                case 4:
                    Environment.Exit(1);
                    break;
                default:
                    Console.WriteLine("NO VALIDADO"); Console.ReadKey();
                    principal();
                    break;
            }
        }
        void newregistro(bool p)// menu de regritro de usuario dependiendo la persona
        {
            Console.Clear();
            Console.WriteLine("REGISTRO?\n");
            Console.WriteLine("1.-ESTUDIANTE\n2.-PROFESOR");
            int op = Convert.ToInt32(Console.ReadLine());
            switch (op)
            {
                case 1:
                    estudiante(p);
                    break;
                case 2:
                    profesor(p);
                    break;
                default:
                    Console.WriteLine("NO VALIDADO"); Console.ReadKey();
                    newregistro(p);
                    break;
            }
        }
        void modificacion()//modificacion de los usuarios ya sea editar o eliminar usuarios
        {
            Console.Clear();
            Console.WriteLine("1.-EDITAR\n2.-ELIMINIAR");
            int op = Convert.ToInt32(Console.ReadLine());
            switch (op)
            {
                case 1:
                    modificacionregistro(true);
                    break;
                case 2:
                    modificacionregistro(false);
                    break;
                default:
                    Console.WriteLine("NO VALIDADO"); Console.ReadKey();
                    modificacion();
                    break;
            }
        }
        void modificacionregistro(bool p)//seleccion de resgistro a modificar ya sea estudiante o profesor
        {
            Console.Clear();
            Console.WriteLine("REGISTRO?\n");
            Console.WriteLine("1.-ESTUDIANTE\n2.-PROFESOR");
            int op = Convert.ToInt32(Console.ReadLine());
            switch (op)
            {
                case 1:
                    buscarestudiante(p);
                    break;
                case 2:
                    buscarprofesor(p);
                    break;
                default:
                    Console.WriteLine("NO VALIDADO"); Console.ReadKey();
                    newregistro(p);
                    break;
            }
        }
        void buscarestudiante(bool p)//modificacion y eliminacion de estudiante
        {
            if (p == true)
            {
                Console.WriteLine("Nombre del estudiante");
                string comparacion = Console.ReadLine();
                foreach (var item in alumno)
                {
                    if (item.busquedanombre(comparacion.ToLower().Trim()))
                    {
                        int op = condicionestudiante();
                        switch (op)
                        {
                            case 1:
                                Console.WriteLine("Nuevo Nombre");
                                item.nuevonombre(Console.ReadLine());
                                principal();
                                break;
                            case 2:
                                Console.WriteLine("Nueva Semestre");
                                item.nuevosemestre(Convert.ToInt32(Console.ReadLine()));
                                break;
                            case 3:
                                Console.WriteLine("Nueva Carrera");
                                item.nuevacarrera(Console.ReadLine());
                                break;
                            case 4:
                                principal();
                                break;
                            default:
                                Console.WriteLine("NO VALIDADO"); Console.ReadKey();
                                buscarestudiante(p);
                                break;
                        }
                    }
                }
            }
            else
            {
                Console.WriteLine("Nombre del estudiante");
                string comparacion = Console.ReadLine();
                for (int i = 0; i < alumno.Count; i++)
                {
                    if (alumno[i].busquedanombre(comparacion.ToLower().Trim()))
                    {
                        alumno.RemoveAt(i);
                        i--;
                        Console.WriteLine("Estudiante Eliminado"); Console.ReadKey();
                    }
                }
                principal();

            }
        }
        void buscarprofesor(bool p)//modificacion y eliminacion de profesor
        {
            if (p == true)
            {
                Console.WriteLine("Nombre del Profesor");
                string comparacion = Console.ReadLine();
                foreach (var item in _profesor)
                {
                    if (item.busquedanombre(comparacion.ToLower().Trim()) == true)
                    {
                        int op = condicionprofesor();
                        switch (op)
                        {
                            case 1:
                                Console.WriteLine("Nuevo Nombre");
                                item.nuevonombre(Console.ReadLine());
                                principal();
                                break;
                            case 2:
                                Console.WriteLine("Nuevo Puesto");
                                item.nuevopuesto(Convert.ToString(Console.ReadLine()));
                                break;
                            case 3:
                                Console.WriteLine("Nueva Area");
                                item.nuevoarea(Console.ReadLine());
                                break;
                            case 4:
                                Console.WriteLine("Nueva Materia");
                                item.nuevamateria(Console.ReadLine());
                                break;
                            case 5:
                                principal();
                                break;
                            default:
                                Console.WriteLine("NO VALIDADO"); Console.ReadKey();
                                principal();
                                break;
                        }
                    }
                }
            }
            else
            {
                Console.WriteLine("Nombre del Profesor");
                string comparacion = Console.ReadLine();
                for (int i = 0; i < _profesor.Count; i++)
                {
                    if (_profesor[i].busquedanombre(comparacion.ToLower().Trim()))
                    {
                        _profesor.RemoveAt(i);
                        i--;
                        Console.WriteLine("Pofesor Eliminado"); Console.ReadKey();
                    }
                }
                principal();

            }
        }
        int condicionestudiante()
        {
            Console.Clear();
            Console.WriteLine("\nEDICION A?");
            Console.WriteLine("1.-Nombre\n2.-Carrera\n3.-Semestre\n4.-Salir");
            return Convert.ToInt32(Console.ReadLine());
        }//condicion de edicion por metodo de enum retornando un numero entero
        int condicionprofesor()//metodo de edicion de la lista
        {
            int i = 1;
            Console.Clear();
            Console.WriteLine("\nEDICION A?");
            foreach (var item in Enum.GetValues(typeof(edicion)))
            {
                Console.WriteLine($"[{i++}]{item}");
            }
            edicion op = (edicion)(Convert.ToInt32(Console.ReadLine()));
            switch (op)
            {
                case edicion.nombre:
                    return 1;
                case edicion.puesto:
                    return 2;
                case edicion.area:
                    return 3;
                case edicion.materia:
                    return 4;
                case edicion.salir:
                    return 5;
                default:
                    principal();
                    break;
            }
            return 0;

        }
        void estudiante(bool p)//insercion y visualizacion de lista metodo .add de estudiante
        {
            if (p == true)
            {

                Console.WriteLine("Cantidad de Alumnos");
                int integrantes = Convert.ToInt32(Console.ReadLine());
                for (int i = 1; i < integrantes + 1; i++)
                {
                    Console.WriteLine("Nombre");
                    _nombre = Console.ReadLine();
                    Console.WriteLine("Fecha de Nacimiento");
                    _edad = Convert.ToDateTime(Console.ReadLine());
                    Console.WriteLine("Carrera");
                    _carrera = Console.ReadLine();
                    Console.WriteLine("Semestre actual");
                    _semestre = Convert.ToInt32(Console.ReadLine());
                    alumno.Add(new estudiate(Nombre: _nombre, Edad: _edad, carrera: _carrera, semestre: _semestre));
                }
                Console.WriteLine("MENU PRINCIPAL?\n1.-Si\n2.-No");
                int salir = Convert.ToInt32(Console.ReadLine());
                if (salir == 1) { principal(); } else { Environment.Exit(1); }
                Console.ReadKey();
            }
            else
            {
                foreach (var item in alumno)
                {
                    item.salidapersona();
                    Console.WriteLine("------------");
                    item.print();
                }
                Console.ReadKey();
                principal();
            }
        }
        void profesor(bool p)//insercion y visualizacion de lista por metodo .add de profesor
        {
            if (p == true)
            {
                Console.WriteLine("Cantidad de profesores");
                int integrantes = Convert.ToInt32(Console.ReadLine());
                for (int i = 1; i < integrantes + 1; i++)
                {
                    Console.WriteLine("Nombre");
                    _nombre = Console.ReadLine();
                    Console.WriteLine("Fecha de Nacimiento");
                    _edad = Convert.ToDateTime(Console.ReadLine());
                    Console.WriteLine("Materia");
                    string Materia = Console.ReadLine();
                    Console.WriteLine("Area actual");
                    string Area = Console.ReadLine();
                    Console.WriteLine("Salario Actual");
                    double Salario = Convert.ToDouble(Console.ReadLine());
                    _profesor.Add(new profesor(area: Area, materia: Materia, puesto: "Profesor", salario: Salario, Nombre: _nombre, Edad: _edad));
                }
                Console.WriteLine("MENU PRINCIPAL?\n1.-SI\n2.-NO");
                int salir = Convert.ToInt32(Console.ReadLine());
                if (salir == 1) { principal(); } else { Environment.Exit(1); }
                Console.ReadKey();
            }
            else
            {
                foreach (var item in _profesor)
                {
                    item.saludo();
                    Console.WriteLine("------------");
                    item.print();
                    item.imprimirid();
                }
                Console.ReadKey();
                principal();
            }
        }
        void registro()
        {
            _profesor.Add(new profesor(area: "ESCAT", materia: "MATEMATICAS", puesto: "Profesor", salario: 8000, Nombre: "Alan Brito Delgado", Edad: new DateTime(1990, 5, 1)));
            _profesor.Add(new profesor(area: "ESCAT", materia: "FISICA", puesto: "Profesor", salario: 8500.15, Nombre: "Jose Boquita de La Corona", Edad: new DateTime(1995, 9, 1)));
            _profesor.Add(new profesor(area: "ESCAT", materia: "PROGRAMACION", puesto: "Profesor", salario: 5200.10, Nombre: "Dolorez De Cueva", Edad: new DateTime(1985, 4, 1)));
            alumno.Add(new estudiate(Nombre: "ZoYla sorda", Edad: new DateTime(1995, 4, 1), carrera: "SISTEMAS", semestre: 5));
            alumno.Add(new estudiate(Nombre: "Alex Plosivo", Edad: new DateTime(199, 8, 2), carrera: "ADMINISTRACION", semestre: 8));
            alumno.Add(new estudiate(Nombre: "Zoyla Vaca", Edad: new DateTime(1995, 5, 9), carrera: "MECATRONICA", semestre: 7));
        }//registro de ususarios predetermindados
    }
}
