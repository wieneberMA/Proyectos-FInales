﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace herencia29102020
{
    class persona
    {
        protected string nombre;
        protected int edad;
        protected DateTime fecha;
        public persona(string Nombre, DateTime Edad)
        {
            nombre = Nombre;
            edad = salida(Edad);
            this.fecha = Edad;
        }//constructor
        int salida(DateTime x)
        {
            int edadanios = ((TimeSpan)(DateTime.Now - x)).Days;
            return edadanios / 365;
        }//insertar edad en anios
        public virtual void salidapersona()
        {
            Console.WriteLine($"\nsaludo desde persona :[{nombre}]");
        }//imprimir nombre
    }

}
