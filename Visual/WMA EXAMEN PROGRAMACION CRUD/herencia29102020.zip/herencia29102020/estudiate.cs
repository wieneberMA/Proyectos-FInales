﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace herencia29102020
{
    class estudiate : persona
    {
        protected int id { get; set; }
        protected string carrera { get; set; }
        protected int semestre { get; set; }
        public estudiate(string Nombre, DateTime Edad, string carrera, int semestre) : base(Nombre, Edad)
        {
            this.id = generarid(id);
            this.carrera = carrera;
            this.semestre = semestre;
        }
        private int generarid(int id)
        {
            var seed = Environment.TickCount;
            var Random = new Random(seed);
            return id = Random.Next(0, 500);
        }//generacion de credencial
        public void print()
        {
            Console.WriteLine($"nombre:[{nombre}] \nEdad:[{edad}] carrera:[{carrera}]\nsemestre:[{semestre}]\n ID:[{id + 1}]");
        }//imprimir estudiante
        public bool busquedanombre(string entrada)
        {
            return nombre.ToLower().Trim().Contains(entrada);
        }//retorna el nombre
        public virtual void nuevonombre(string nuevonombre)
        {
            this.nombre = nuevonombre;
            Console.WriteLine("Nombre agregado");
        }//asigna un nuevo nombre a la clase
        public virtual void nuevosemestre(int nuevosemestre)
        {
            this.semestre = nuevosemestre;
            Console.WriteLine("Semestre agregado");
        }//asigna un nuevo semestre a la clase
        public virtual void nuevacarrera(string nuevacarrera)
        {
            this.carrera = nuevacarrera; Console.WriteLine("carrera agregada");
        }//asinga una nueva carrera a la clase
        public override void salidapersona()
        {
            Console.WriteLine($"saludo desde estudiante {nombre}");

        }
    }
}
