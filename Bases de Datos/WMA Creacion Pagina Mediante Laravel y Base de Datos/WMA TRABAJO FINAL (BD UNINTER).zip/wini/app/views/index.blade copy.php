<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    
    <title>Vista General!</title>
  </head>
  <body>
  <h1 class="display -1" align="center"><samp class="text-muted">CRUD DE HEROES</samp> </h1>

  <nav id="topNav" class="navbar navbar-default main-menu">
    <div class="container">
        <button class="navbar-toggler hidden-md-up pull-right" type="button" data-toggle="collapse" data-target="#collapsingNavbar">
            ☰
        </button> 
		 <a class = "btn" class="display -1" >LISTA DE OPCIONES</a>
		 <br>
        <div class="collapse navbar-toggleable-sm" id="collapsingNavbar">
            <ul class="nav navbar-nav">
                 <li class="active" >
					 	<form action="{{URL::asset("vista")}}" align="center">
						<input class = "btn btn-primary" type="submit" name="" value="ver listado heroes">
						</form>
                    </li>
					<li>
						<br>
							<form action="{{URL::asset("vistav")}}" align="center">
								<input class = "btn btn-primary" type="submit" name="" value="ver listado villanos">
							</form>
						</br>
                    </li>
                    <li>
						<form action="{{URL::asset("fondonegro")}}" align="center">
							<input class = "btn btn-primary" type="submit" name="" value="tema oscuro">
						</form>
                    </li>
            </ul> 
        </div>
    </div>
</nav>
    <div align="center">
		@if(Session::get('mensaje'))
			{{Session::get('mensaje')}}
		@endif
	</div>
	<br>	
	



    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
  </body>
</html>
