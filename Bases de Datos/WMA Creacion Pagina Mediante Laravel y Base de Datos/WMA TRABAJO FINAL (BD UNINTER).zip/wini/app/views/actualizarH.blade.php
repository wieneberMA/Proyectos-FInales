<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Actualizar Héroe</title>
</head>
<body>
<h1 align="center">Actualizar Héroe</h1>
<form align="center"action="{{ URL::asset("actualizarH") }}">
		<input type="hidden" name="idH" value="{{$idHeroe}}"><br>
		<input type="text" name="nombreH" value="{{$nombreHeroe}}"><br>
        <input type="text" name="identidadR" value="{{$identidadReal}}"><br>
        <input type="text" name="statusH" value="{{$statusHeroe}}"><br>
		<input type="submit" name="" id="" value="Actualizar">
	</form>
</body>
</html>