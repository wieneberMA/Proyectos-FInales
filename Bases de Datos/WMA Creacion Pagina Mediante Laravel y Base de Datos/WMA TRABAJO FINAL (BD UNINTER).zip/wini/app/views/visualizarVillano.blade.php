<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
	<title>Vista General!</title>
	<script language="JavaScript">
	function pregunta(){
			if (confirm('los villanos que se registraron nuevo solo se pueden eliminar o cambiar el estado de vivo a muerto')){
			document.tuformulario.submit()
				}
	}
	</script>



    <title>Vista General!</title>
  </head>
  <body>
    
  <h1 align="center">Vista de Personajes villanos</h1>
	<br>
	<form action="{{URL::asset("crearvillano")}}" align="center">
			<input class = "btn btn-primary " type="submit" name="" value="Agregar registro villano">
		</form>
	</br>

  @if( count($tabla)>0)
		<table border=".5" align="center" class="table table-dark">
			<thead>
				<tr>
					<th>NOMBRE</th>
					<th>REAL</th>
					<th>STATUS</th>
					<th>Eliminar</th>
					<th>Modificar</th>
				</tr>
			</thead>
			<tbody>
				@foreach ( $tabla as $busq)
					<tr>
						<td> {{$busq->nombreVillano}} </td>
						<td>{{ $busq->identidadReal}}</td>
						<td>{{ $busq->statusvillano}}</td>
						<td><a onclick="pregunta()" href="{{ URL::asset("eliminarv/".$busq->idVillano) }}">Eliminar</a></td>
						<td><a href="{{ URL::asset("modificarV/".$busq->idVillano.'/'.$busq->nombreVillano.'/'.$busq->identidadReal.'/'.$busq->statusvillano) }}">Modificar</a></td>
					</tr>
				@endforeach
			</tbody>
		</table>
    @endif
    <div align="center">
		@if(Session::get('mensaje'))
			{{Session::get('mensaje')}}
		@endif
	</div>
	<br>
	
		<form action="{{URL::asset("/")}}" align="center">
			<input class = "btn btn-primary " type="submit" name="" value="regresar">
		</form>
	</br>
   

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
  </body>
</html>



