@extends('coverF')
    <title>Inicio</title>
</head>
<body>
	@section('titulo')
		<h3 > HEROES DC COMICS</h3>
	@stop
    <div align="center">
		@if(Session::get('mensaje'))
			{{Session::get('mensaje')}}
		@endif
	</div>
	@section('boton')

			<form action="{{URL::asset("vista")}}" align="center">
				<input class="btn btn-outline-light" type="submit" name="" value="ver listado heroes">
			</form>

			<form action="{{URL::asset("vistav")}}" align="center">
				<input class="btn btn-outline-light" type="submit" name="" value="ver listado villanos">
			</form>



	@stop

	<form action="{{URL::asset("salir")}}" align="center">
		<input class="btn btn-danger type="submit" name="" value="LogOut">
	</form>


	
</body>
</html>


