<?php

class HomeController extends BaseController {

	/*
	|--------------------------------------------------------------------------
	| Default Home Controller
	|--------------------------------------------------------------------------
	|
	| You may wish to use controllers instead of, or in addition to, Closure
	| based routes. That's great! Here is an example controller method to
	| get you started. To route to this controller, just add the route:
	|
	|	Route::get('/', 'HomeController@showWelcome');
	|
	*/

	public function showWelcome()
	{
		return View::make('login');
	}
	public function showfondonegro(){
		return View::make('coverF');
	}

	public function vistaAgregar()
	{
		return View::make('agregar');
	}


	public function vistaAgregarvillano()
	{
		return View::make('agregarv');
	}


	public function vistatodosvillanos()
	{
		return View::make('vistavillano');
	}


	public function showAllHeroe()
	{
		$tabla = DB::select("SELECT idHeroe,nombreHeroe,identidadReal,statusHeroe FROM heroe");

			return View::make('visualizarHeroe')->with(array('tabla' => $tabla));		
	}


	public function showAllvillano()
	{
		$tabla = DB::select("SELECT idVillano,nombreVillano,identidadReal,statusvillano FROM villano");

			return View::make('visualizarVillano')->with(array('tabla' => $tabla));		
	}


	public function deleteHeroe($idHeroe)
	{							
			DB::table('heroe')
			->where('idHeroe', $idHeroe)
			->delete();
			return Redirect::to("vista")->with(array('mensaje' => "Heroe eliminado correctamente"));
	}

	public function deleteVillano($idVillano)
	{							
			DB::table('villano')
			->where('idVillano', $idVillano)
			->delete();
			return Redirect::to("vistav")->with(array('mensaje' => "Villano eliminado correctamente"));
	}

	public function addH()
	{
		$nombreH = Input::get('nombre');
		$identidadR = Input::get('identidad');
		$statusH = Input::get('status');
		DB::table('heroe')->insert(
			[
				'nombreHeroe' => $nombreH,
				'identidadReal' => $identidadR,
				'statusHeroe' => $statusH
			]
		);
		return Redirect::to("vista")->with(array('mensaje' => "Heroe agregado correctamente"));
	}

	public function addV()
	{
		$nombreV = Input::get('nombrev');
		$identidadRV = Input::get('identidadv');
		$statusV = Input::get('statusv');
		DB::table('villano')->insert(
			[
				'nombreVillano' => $nombreV,
				'identidadReal' => $identidadRV,
				'statusVillano' => $statusV
			]
		);
		return Redirect::to("vistav")->with(array('mensaje' => "vilano agregado correctamente"));
	}

	public function showUpdateH($idHeroe, $nombreHeroe, $identidadReal, $statusHeroe)
	{
		return View::make('actualizarH')->with(array('idHeroe' => $idHeroe, 'nombreHeroe' => $nombreHeroe, 'identidadReal' => $identidadReal, 'statusHeroe' => $statusHeroe));
	}

	public function showUpdateV($idVillano , $nombreVillano, $identidadReal, $statusVillano)
	{
		return View::make('actualizarV')->with(array('idVillano' => $idVillano, 'nombreVillano' => $nombreVillano, 'identidadReal' => $identidadReal, 'statusVillano' => $statusVillano));
	}

	public function updateH()
	{
		$idHeroe = Input::get('idH');
		$nombreH = Input::get('nombreH');
		$identidadR = Input::get('identidadR');
		$statusH = Input::get('statusH');
		
		DB::table('heroe')
			->where('idHeroe', $idHeroe)
			->update(['nombreHeroe' => $nombreH, 'identidadReal' => $identidadR, 'statusHeroe' => $statusH]);

		return Redirect::to("vista")->with(array('mensaje' => "Heroe actualizado correctamente"));
	}

	public function updateV()
	{
		$idVillano = Input::get('idV');
		$nombreV = Input::get('nombreV');
		$identidadR = Input::get('identidadR');
		$statusV = Input::get('statusV');
		
		DB::table('villano')
			->where('idVillano', $idVillano)
			->update(['nombreVillano' => $nombreV, 'identidadReal' => $identidadR, 'statusVillano' => $statusV]);

		return Redirect::to("vistav")->with(array('mensaje' => "villano actualizado correctamente"));
	}

	function login(){
		$user = Input::get('user');
		$password = Input::get('password');
		if (!empty($user) || !empty($password)) {
			$usuario= DB::select("
				SELECT nombreUser, passwordUser
				FROM user 
				WHERE nombreUser = '".$user."' and passwordUser = '".$password."'
			");
			if(count($usuario) > 0)
			{
				Session::flush();
				Session::push('login', true);
				Session::save();
				return View::make("index");
			}else{
				return Redirect::to("/")->with(array('mensaje'=>'Datos incorrectos'));	
			}
		} else{
			return Redirect::to("/")->with(array('mensaje'=>'Campos vacios'));
		}

	}

	function salir(){
		Session::flush();
		Session::save();
		return Redirect::to("/");
	}
}
