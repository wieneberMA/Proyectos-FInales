<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the Closure to execute when that URI is requested.
|
*/

/*Route::get('/', function()
{
	return View::make('index');
});*/

Route::get('/', "HomeController@showWelcome");
Route::post('login', "HomeController@login");
Route::get('salir', "HomeController@salir");

Route::group(array('before'=>"is_login"), function(){
	Route::get('fondonegro', "HomeController@showfondonegro");
	Route::get('crear', "HomeController@vistaAgregar");
	Route::get('crearvillano', "HomeController@vistaAgregarvillano");
	Route::get('vista', "HomeController@showAllHeroe");
	Route::get('vistav', "HomeController@showAllvillano");
	Route::get('eliminar/{idHeroe}', "HomeController@deleteHeroe");
	Route::get('eliminarv/{idVillano}', "HomeController@deleteVillano");
	Route::get('agregarH',"HomeController@addH");
	Route::get('agregarV',"HomeController@addV");
	Route::get('modificarH/{idHeroe}/{nombreHeroe}/{identidadReal}/{statusHeroe}', "HomeController@showUpdateH");
	Route::get('modificarV/{idVillano}/{nombreVillano}/{identidadReal}/{statusVillano}', "HomeController@showUpdateV");
	Route::get('actualizarH', "HomeController@updateH");
	Route::get('actualizarV', "HomeController@updateV");
});